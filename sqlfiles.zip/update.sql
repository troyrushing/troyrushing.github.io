ALTER TABLE employees ADD COLUMN gender VARCHAR(4) NOT NULL;

UPDATE employees SET gender = "M" WHERE employee_id > 0;

UPDATE employees SET gender = "F" WHERE employee_id = 2;

INSERT INTO employees (first_name, last_name, user_name, password, hash_value, gender)
VALUES ("Troy", "Rushing", "troy.rushing", "pass", "d1f47180ed01c2f5c972cac7aef8c811", "M");