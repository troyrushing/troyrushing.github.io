SELECT * FROM employees ORDER BY last_name;

SELECT * FROM employees WHERE last_name = "Grizzlybear";

SELECT user_name FROM employees;

SELECT first_name, last_name FROM employees
    WHERE first_name = "Rosario" OR last_name = "Grizzlybear";

SELECT * FROM employees WHERE last_name LIKE 'g%';

SELECT * FROM jobs WHERE access LIKE '%animal%';

SELECT * FROM jobs WHERE job_title REGEXP '^.{9}$';

SELECT COUNT(*) FROM employees_jobs;

SELECT gender, COUNT(*) FROM employees GROUP BY gender;

SELECT employees.first_name, employees.last_name, jobs.job_title
FROM employees
INNER JOIN employees_jobs ON employees_jobs.employee_id = employees.employee_id
INNER JOIN jobs ON jobs.job_id = employees_jobs.job_id
