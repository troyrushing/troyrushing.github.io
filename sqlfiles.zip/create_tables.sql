CREATE DATABASE zoo;

USE zoo;

CREATE TABLE employees ( 
    employee_id INT(8) UNSIGNED NOT NULL auto_increment,
    first_name VARCHAR(25) NOT NULL,
    last_name VARCHAR(25) NOT NULL,
    user_name VARCHAR(25) NOT NULL,
    password VARCHAR(25) NOT NULL,
    hash_value VARCHAR(40) NOT NULL,
    PRIMARY KEY (employee_id)
) AUTO_INCREMENT=1;

CREATE TABLE jobs ( 
    job_id INT(8) UNSIGNED NOT NULL auto_increment,
    job_title VARCHAR(25) NOT NULL,
    access VARCHAR(255) NOT NULL,
    PRIMARY KEY (job_id)
) AUTO_INCREMENT=1;

CREATE TABLE employees_jobs (
    employee_id INT(8) UNSIGNED NOT NULL,
    job_id INT(8) UNSIGNED NOT NULL, 
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    FOREIGN KEY (job_id) REFERENCES jobs(job_id)
);

INSERT INTO employees (first_name, last_name, user_name, password, hash_value)
VALUES ("Griffin", "Keyes", "griffin.keys", "alphabet soup", "cafc7170ed01c2f5c972cac7cde6e932");

INSERT INTO employees (first_name, last_name, user_name, password, hash_value)
VALUES ("Rosario", "Dawson", "rosario.dawson", "animal doctor", "1e4483e833025ac10e6184e75cb2d19d");

INSERT INTO employees (first_name, last_name, user_name, password, hash_value)
VALUES ("Bernie", "gorilla", "bernie.gorilla", "secret password", "5ebe2294ecd0e0f08eab7690d2a6ee69");

INSERT INTO employees (first_name, last_name, user_name, password, hash_value)
VALUES ("Donald", "Monkey", "donald.monkey", "M0nk3y business", "54b34e64d39a0500d973a27def1ddc51");

INSERT INTO employees (first_name, last_name, user_name, password, hash_value)
VALUES ("Jerome", "Grizzlybear", "jerome.grizzlybear", "grizzly1234", "3adea92111e6307f8f2aae4721e77900");

INSERT INTO employees (first_name, last_name, user_name, password, hash_value)
VALUES ("Bruce", "Grizzlybear", "bruce.grizzlybear", "letmein", "0d107d09f5bbe40cade3de5c71e9e9b7");


INSERT INTO jobs (job_title, access)
VALUES ("Administrator", "Main computer access");

INSERT INTO jobs (job_title, access)
VALUES ("Veterinarian", "All animals' health records");

INSERT INTO jobs (job_title, access)
VALUES ("Zookeeper", "All animals' information and daily monitoring logs");


INSERT INTO employees_jobs (employee_id, job_id)
VALUES (1, 3);

INSERT INTO employees_jobs (employee_id, job_id)
VALUES (2, 1);

INSERT INTO employees_jobs (employee_id, job_id)
VALUES (3, 2);

INSERT INTO employees_jobs (employee_id, job_id)
VALUES (4, 3);

INSERT INTO employees_jobs (employee_id, job_id)
VALUES (5, 2);

INSERT INTO employees_jobs (employee_id, job_id)
VALUES (6, 1);